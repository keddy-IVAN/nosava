const CACHE_NAME = 'nosava-pwa-v3';
const APP_BASE = self.registration.scope;
const INDEX_URL = new URL('index.html', APP_BASE).href;
const PRECACHE_URLS = [
  './index.html',
  './manifest.webmanifest',
  './icons/nosava-180.png',
  './icons/nosava-192.png',
  './icons/nosava-512.png',
  './vendor/three.min.js',
  './vendor/RGBELoader.js',
  './vendor/GLTFLoader.js',
  './vendor/THREE-LICENSE.txt',
  './assets/kloofendal_48d_partly_cloudy_puresky_1k.hdr',
  './assets/plants/anthurium_botany_01_1k.gltf',
  './assets/plants/anthurium_botany_01.bin',
  './assets/plants/textures/anthurium_botany_01_nor_gl_1k.jpg',
  './assets/plants/textures/anthurium_botany_01_diff_1k.jpg',
  './assets/plants/textures/anthurium_botany_01_arm_1k.jpg',
  './assets/ASSET-CREDITS.txt'
].map(url => new URL(url, APP_BASE).href);

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key.startsWith('nosava-pwa-') && key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin)
    return;

  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(INDEX_URL, copy));
          }
          return response;
        })
        .catch(() => caches.match(INDEX_URL))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(cached => cached || fetch(event.request).then(response => {
        if (!response.ok)
          return response;
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        return response;
      }))
  );
});
